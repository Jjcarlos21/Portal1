import os
import sqlite3
from flask import Flask, abort, render_template, url_for

from content import PILOT_DIRECTORY_PAGES

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "data", "kizuna.db")

app = Flask(__name__, template_folder=os.path.join(BASE_DIR, "templates"),
            static_folder=os.path.join(BASE_DIR, "static"))


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def normalize_asset_path(value):
    """Convert legacy DB paths into Flask static URLs."""
    if not value or str(value).strip().lower() in {"none", "null"}:
        return None
    value = str(value).strip().replace("\\", "/")
    if value.startswith("http://") or value.startswith("https://"):
        return value
    if value.startswith("/static/"):
        return value
    if value.startswith("static/"):
        return "/" + value
    return url_for("static", filename=value.lstrip("/"))


def normalize_record(row):
    item = dict(row)
    for key in ("logo", "foto1", "foto2", "foto3", "foto4"):
        item[key] = normalize_asset_path(item.get(key))
    return item


def get_directory_records(activity):
    conn = get_db()
    try:
        # Column names are controlled by the application data model, not user input.
        rows = conn.execute(
            f"SELECT * FROM directorio WHERE {activity} = 1 ORDER BY Estado, Ciudad, Nombre"
        ).fetchall()
        return [normalize_record(row) for row in rows]
    finally:
        conn.close()


def group_records(records):
    caracas = []
    grouped = {}
    for item in records:
        city = str(item.get("Ciudad") or "").strip()
        state = str(item.get("Estado") or "").strip()
        zone = str(item.get("Zona") or "").strip()

        if city.casefold() == "caracas" or state.casefold() in {"caracas", "distrito capital"} or zone.casefold() == "caracas":
            caracas.append(item)
        else:
            state_name = state or "Otros Estados"
            city_name = city or "Otras Ciudades"
            grouped.setdefault(state_name, {}).setdefault(city_name, []).append(item)

    return caracas, dict(sorted(
        ((state, dict(sorted(cities.items(), key=lambda x: x[0].casefold())))
         for state, cities in grouped.items()),
        key=lambda x: x[0].casefold()
    ))


@app.route("/")
def index():
    return render_template("pages/home.html")


@app.route("/cultura/<slug>")
def culture_detail(slug):
    page = PILOT_DIRECTORY_PAGES.get(slug)
    if not page:
        abort(404)
    records = get_directory_records(page["activity"])
    caracas, states = group_records(records)
    return render_template(
        "pages/detail.html",
        page=page,
        caracas=caracas,
        states=states,
    )


@app.errorhandler(404)
def not_found(_error):
    return render_template("pages/404.html"), 404


if __name__ == "__main__":
    app.run(debug=True, host="127.0.0.1", port=5000)
